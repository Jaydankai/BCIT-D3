function learnmore() {
  var elmnt = document.getElementById("div2");
  elmnt.scrollIntoView({behavior: "smooth"});
}
function back(){
  var elmnt = document.getElementById("div2");
  elmnt.scrollIntoView({behavior: "smooth"});
}
function viewinfoBCM(){
  var elmnt = document.getElementById("divBCM");
  elmnt.scrollIntoView({behavior: "smooth"});
}
function viewinfoCTE(){
  var elmnt = document.getElementById("divCTE");
  elmnt.scrollIntoView({behavior: "smooth"});
}
function viewinfoDCD(){
  var elmnt = document.getElementById("divDCD");
  elmnt.scrollIntoView({behavior: "smooth"});
}
function viewinfoDSF(){
  var elmnt = document.getElementById("divDSF");
  elmnt.scrollIntoView({behavior: "smooth"});
}
function viewinfoDS1(){
  var elmnt = document.getElementById("divDS1");
  elmnt.scrollIntoView({behavior: "smooth"});
}
function viewinfoPJM(){
  var elmnt = document.getElementById("divPJM");
  elmnt.scrollIntoView({behavior: "smooth"});
}
function viewinfoPSD(){
  var elmnt = document.getElementById("divPSD");
  elmnt.scrollIntoView({behavior: "smooth"});
}
function viewinfoVAE(){
  var elmnt = document.getElementById("divVAE");
  elmnt.scrollIntoView({behavior: "smooth"});
}
function viewinfoWBM(){
  var elmnt = document.getElementById("divWBM");
  elmnt.scrollIntoView({behavior: "smooth"});
}
function viewinfoWD2(){
  var elmnt = document.getElementById("divWD2");
  elmnt.scrollIntoView({behavior: "smooth"});
}

function BCMbackground(){
    document.getElementById("div2").style.backgroundImage="linear-gradient(to bottom right, RGB(66, 53, 247), RGB(254, 144, 246))";
}
function CTEbackground(){
    document.getElementById("div2").style.backgroundImage="linear-gradient(to bottom right, RGB(252, 244, 32), RGB(241, 93, 33))";
}
function DCDbackground(){
    document.getElementById("div2").style.backgroundImage="linear-gradient(to top left, RGB(252, 244, 32), RGB(238, 37, 82))";
}
function DS1background(){
    document.getElementById("div2").style.backgroundImage="linear-gradient(to bottom left, RGB(249, 179, 133), RGB(236, 18, 29))";
}
function DSFbackground(){
    document.getElementById("div2").style.backgroundImage="linear-gradient(to bottom right, RGB(240, 22, 116), RGB(187, 145, 194))";
}
function PJMbackground(){
    document.getElementById("div2").style.backgroundImage="linear-gradient(to bottom left, RGB(192, 223, 115), RGB(0, 165, 67))";
}
function PSDbackground(){
    document.getElementById("div2").style.backgroundImage="linear-gradient(to top left, RGB(1, 173, 241), RGB(3, 168, 153))";
}
function VAEbackground(){
    document.getElementById("div2").style.backgroundImage="linear-gradient(to bottom left, RGB(108, 254, 246), RGB(108, 0, 245))";
}
function WBMbackground(){
    document.getElementById("div2").style.backgroundImage="linear-gradient(to top left, RGB(188, 140, 190), RGB(0, 173, 238))";
}
function WD2background(){
    document.getElementById("div2").style.backgroundImage="linear-gradient(to top right, RGB(79, 1, 88), RGB(250, 157, 158))";
}
